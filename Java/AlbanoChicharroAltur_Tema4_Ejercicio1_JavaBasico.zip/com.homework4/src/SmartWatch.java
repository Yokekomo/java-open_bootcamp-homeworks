public class SmartWatch extends SmartDevice{

    public SmartWatch() {
    }

    public SmartWatch(String manufacturer, String model, String color, double price, boolean waterproof, int memory, double screen, String batery) {
        super(manufacturer, model, color, price, waterproof, memory, screen, batery);
    }
}
