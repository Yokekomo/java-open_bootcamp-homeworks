public class SmartPhone extends SmartDevice{

    public static boolean camera;

    public SmartPhone(){
    }

    public SmartPhone(String manufacturer, String model, String color, double price, boolean waterproof, int memory, double screen, String batery, boolean camara) {
        super(manufacturer, model, color, price, waterproof, memory, screen, batery);
        this.camera = camara;
    }
}
