public class CocheCRUDImpl implements CocheCRUD{

    public CocheCRUDImpl(){
    }

    public void save() {
        System.out.println("Save");
    }

    public void findAll() {
        System.out.println("FindAll");
    }

    public void delete() {
        System.out.println("Delete");
    }
}
