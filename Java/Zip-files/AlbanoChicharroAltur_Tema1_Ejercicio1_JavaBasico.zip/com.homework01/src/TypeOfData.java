public class TypeOfData {

    public static void main(String[] args) {

        byte variable1 = 5;
        short variable2 = 10;
        int variable3 = 30;
        long variable4 = 100;
        float variable5 = 5.5f;
        double variable6 = 10.5d;
        boolean variable7 = false;
        boolean variable8 = true;
        char variable9 = 'a';
        String variable10 = "Soy un String";
        char variable11 = '"';

        System.out.println("TIPOS DE DATOS");
        System.out.println();
        System.out.println("Numéricos que a su vez se dividen en:");
        System.out.println("Enteros:");
        System.out.println("byte variable1 = " + variable1 + ";");
        System.out.println("short variable2 = " + variable2 + ";");
        System.out.println("int variable3 = " + variable3 + ";");
        System.out.println("long variable4 = " + variable4 + ";");
        System.out.println();
        System.out.println("Y decimales:");
        System.out.println("float variable5 = " + variable5 + "f;");
        System.out.println("double variable6 = " + variable6 + "d;");
        System.out.println();
        System.out.println("Pueden ser Booleano:");
        System.out.println("boolean variable7 = " + variable7 + ";");
        System.out.println("boolean variable8 = " + variable8 + ";");
        System.out.println();
        System.out.println("Y por ultimo de texto:");
        System.out.println("char variable9 = " + "'" + variable9 + "'" + ";");
        System.out.println("String variable10 = " + variable11 + variable10 + variable11 + ";");
    }
}
