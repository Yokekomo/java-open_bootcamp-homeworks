import java.util.Arrays;

public class Ejercicio3 {
    public static void main(String[] args) {

        String[] names = {"Juanito", "Pedrito", "Manolito", "Sebastian"};

        for (String name : names) {
            System.out.print(name + " ");
        }
    }
}
